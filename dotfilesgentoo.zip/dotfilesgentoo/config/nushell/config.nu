$env.config = {
    color_config: {
        separator: "#6b4f4f"
        leading_trailing_space_bg: "#3b2929"

        header: { fg: "#f5a6b8" attr: b }
        row_index: { fg: "#e78f9f" }

        record: "#f3d6d0"
        list: "#f3d6d0"
        hints: "#a98282"

        search_result: {
            fg: "#ffd1dc"
            bg: "#5a3d3d"
        }

        string: "#f2b5c4"
        int: "#d98b9a"
        filesize: "#e8b4b8"
        duration: "#c99a9a"
        datetime: "#f0a0b0"
        range: "#d58a9a"
        float: "#e29aaa"
        bool: "#e78f9f"
        nothing: "#8f7070"
        binary: "#e8aeb9"
        cellpath: "#f0a0b0"
    }
}
