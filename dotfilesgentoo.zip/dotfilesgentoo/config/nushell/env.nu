$env.PATH = ($env.PATH | prepend "$HOME/.local/bin")

$env.DISPLAY = ":0"
$env.XDG_RUNTIME_DIR = "/tmp"

$env.LIBGL_ALWAYS_SOFTWARE = "1"
$env.GALLIUM_DRIVER = "llvmpipe"
$env.MESA_LOADER_DRIVER_OVERRIDE = "llvmpipe"

$env.SHELL = "/usr/bin/nu"
