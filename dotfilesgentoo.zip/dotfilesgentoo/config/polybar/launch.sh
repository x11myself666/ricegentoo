#!/usr/bin/env bash

# Hentikan semua process polybar yang sedang berjalan
killall -q polybar

# Tunggu sampai semua process benar-benar mati
while pgrep -u $UID -x polybar >/dev/null; do sleep 1; done

# Jalankan bar "example"
polybar example 2>&1 | tee -a /tmp/polybar.log & disown
