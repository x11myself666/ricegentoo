hello gw x11myself 🫠
gw menjalankan gentoo ini di termux yak 
barang kali ingin dotfiles nya silakan ini gratis dan jika anda ingin mendownload nya anda tinggal
install termux dan buka apk nya
dan install proot distro dan jangan lupa install termux x11 nya
anda bisa menginstall gentoo dengan command 
proot-distro install gentoo/stage3:latest
anda update dengan 
emerge --sync ->>buat update
emerge x11-wm/bspwm
dan jika defensi tambahan 
rofi ,picom ,polybar dan cava(opsional),fastfetch
anda bisa cek di web gentoo bagaimana install defensi di atas 
⚠️jika hp anda merasa sangat panas itu wajar anda bisa menurunkan menjadi -j2 atau -j4 
jangan gunakan -j8 karna akan membuat hp anda sangat panas
