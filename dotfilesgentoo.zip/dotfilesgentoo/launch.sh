#!/usr/bin/env bash

# Set variabel DISPLAY untuk Termux:X11
export DISPLAY=:0

# 1. Hentikan instance Picom dan Polybar yang mungkin sedang berjalan
killall -q picom polybar

# 2. Tunggu sampai proses benar-benar berhenti
while pgrep -u $UID -x picom >/dev/null; do sleep 1; done
while pgrep -u $UID -x polybar >/dev/null; do sleep 1; done

# 3. Jalankan Picom di background (menggunakan config di ~/.config/picom/picom.conf)
if command -v picom >/dev/null; then
    picom -b --config ~/.config/picom/picom.conf &
    echo "Picom berhasil dijalankan."
else
    echo "Peringatan: Picom belum terinstall."
fi

# 4. Jalankan Polybar (menggunakan config di ~/.config/polybar/config.ini)
if command -v polybar >/dev/null; then
    polybar main 2>&1 | tee -a /tmp/polybar.log &
    echo "Polybar berhasil dijalankan."
else
    echo "Peringatan: Polybar belum terinstall."
fi

echo "Semua service tampilan berhasil dijalankan!"
